import React, { Component } from 'react';
import Forminfo from './components/Forminfo.js';

import './App.css';

class App extends Component {
  render() {
    return (
      <div  >
        <Forminfo />
      </div>
    );
  }
}

export default App;
